-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 18, 2016 at 06:40 PM
-- Server version: 5.6.28-0ubuntu0.15.10.1
-- PHP Version: 5.6.11-1ubuntu3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portalpaulinho`
--

-- --------------------------------------------------------

--
-- Table structure for table `denuncia`
--

CREATE TABLE IF NOT EXISTS `denuncia` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bairro` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `complemento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pontoref` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cidade` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `moderador`
--

CREATE TABLE IF NOT EXISTS `moderador` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cargo` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `moderador`
--

INSERT INTO `moderador` (`id`, `nome`, `email`, `cargo`) VALUES
(1, 'Enzo Augusto', 'enzovaughan@outlook.com', 'Desenvolvedor Web');

-- --------------------------------------------------------

--
-- Table structure for table `noticia_principal`
--

CREATE TABLE IF NOT EXISTS `noticia_principal` (
  `id` int(11) NOT NULL,
  `imagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticia_principal`
--

INSERT INTO `noticia_principal` (`id`, `imagem`, `titulo`, `descricao`, `data`, `url`, `status`) VALUES
(1, 'abstraction_painting_girl_paint_flowers_hand_thoughtful_rendering_93862_1366x768.jpg', 'Professor Paulinho investe em saúde', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:45:03', 'professor-paulinho-investe-em-sa-', 1),
(2, 'face_paint_background_92168_1366x768.jpg', 'Professor Paulinho investe em educação', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:49:11', 'professor-paulinho-investe-em-educa-o', 1),
(3, 'wolf_face_abstract_colorful_92879_1366x768.jpg', 'Professor Paulinho investe em acessibilidade', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 17:09:17', 'professor-paulinho-investe-em-acessibilidade', 1),
(4, 'wolf_face_light_lines_74737_1366x768.jpg', 'Professor Paulinho investe em artesanato', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 17:09:45', 'professor-paulinho-investe-em-artesanato', 1),
(5, 'php-code1.jpg', 'Professor Paulinho investe em tecnologia', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 17:10:00', 'professor-paulinho-investe-em-tecnologia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `noticia_quaternaria`
--

CREATE TABLE IF NOT EXISTS `noticia_quaternaria` (
  `id` int(11) NOT NULL,
  `imagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticia_quaternaria`
--

INSERT INTO `noticia_quaternaria` (`id`, `imagem`, `titulo`, `descricao`, `data`, `url`, `status`) VALUES
(1, 'abstraction_painting_girl_paint_flowers_hand_thoughtful_rendering_93862_1366x7683.jpg', 'Professor Paulinho investe em saúde', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:52:31', 'professor-paulinho-investe-em-sa-', 1),
(2, 'face_paint_background_92168_1366x7683.jpg', 'Professor Paulinho investe em educação', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:52:41', 'professor-paulinho-investe-em-educa-o', 1),
(3, 'php-code.jpg', 'Professor Paulinho investe em tecnologia', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:39:10', 'professor-paulinho-investe-em-tecnologia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `noticia_quinaria`
--

CREATE TABLE IF NOT EXISTS `noticia_quinaria` (
  `id` int(11) NOT NULL,
  `imagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticia_quinaria`
--

INSERT INTO `noticia_quinaria` (`id`, `imagem`, `titulo`, `descricao`, `data`, `url`, `status`) VALUES
(3, 'abstraction_painting_girl_paint_flowers_hand_thoughtful_rendering_93862_1366x7686.jpg', 'Professor Paulinho investe em saúde', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:26:43', 'professor-paulinho-investe-em-sa-', 1),
(4, 'face_paint_background_92168_1366x7685.jpg', 'Professor Paulinho investe em educação', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:26:57', 'professor-paulinho-investe-em-educa-o', 1),
(5, 'wolf_face_drawing_spot_92784_1366x768.jpg', 'Professor Paulinho investe em acessibilidade', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:41:24', 'professor-paulinho-investe-em-acessibilidade', 1);

-- --------------------------------------------------------

--
-- Table structure for table `noticia_secundaria`
--

CREATE TABLE IF NOT EXISTS `noticia_secundaria` (
  `id` int(11) NOT NULL,
  `imagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticia_secundaria`
--

INSERT INTO `noticia_secundaria` (`id`, `imagem`, `titulo`, `descricao`, `data`, `url`, `status`) VALUES
(1, 'abstraction_painting_girl_paint_flowers_hand_thoughtful_rendering_93862_1366x7681.jpg', 'Professor Paulinho investe em saúde', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:51:26', 'professor-paulinho-investe-em-sa-', 1),
(2, 'face_paint_background_92168_1366x7681.jpg', 'Professor Paulinho investe em educação', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:51:45', 'professor-paulinho-investe-em-educa-o', 1),
(3, 'line_light_pattern_stripes_colorful_88549_1366x768.jpg', 'Professor Paulinho investe em biologia', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:38:22', 'professor-paulinho-investe-em-biologia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `noticia_senaria`
--

CREATE TABLE IF NOT EXISTS `noticia_senaria` (
  `id` int(11) NOT NULL,
  `imagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticia_senaria`
--

INSERT INTO `noticia_senaria` (`id`, `imagem`, `titulo`, `descricao`, `data`, `url`, `status`) VALUES
(3, 'abstraction_painting_girl_paint_flowers_hand_thoughtful_rendering_93862_1366x7685.jpg', 'Professor Paulinho investe em saúde', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:23:40', 'professor-paulinho-investe-em-sa-', 1),
(4, 'face_paint_background_92168_1366x7684.jpg', 'Professor Paulinho investe em educação', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:26:31', 'professor-paulinho-investe-em-educa-o', 1);

-- --------------------------------------------------------

--
-- Table structure for table `noticia_terciaria`
--

CREATE TABLE IF NOT EXISTS `noticia_terciaria` (
  `id` int(11) NOT NULL,
  `imagem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `data` datetime NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticia_terciaria`
--

INSERT INTO `noticia_terciaria` (`id`, `imagem`, `titulo`, `descricao`, `data`, `url`, `status`) VALUES
(1, 'abstraction_painting_girl_paint_flowers_hand_thoughtful_rendering_93862_1366x7682.jpg', 'Professor Paulinho investe em saúde', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:51:59', 'professor-paulinho-investe-em-sa-', 1),
(2, 'face_paint_background_92168_1366x7682.jpg', 'Professor Paulinho investe em educação', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 15:52:11', 'professor-paulinho-investe-em-educa-o', 1),
(3, 'universe_space_nebula_galaxy_102009_1366x768.jpg', 'Professor Paulinho investe em artesanato', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus \naccumsan ipsum in diam semper maximus. Fusce mattis diam risus, ut \npharetra quam mollis a. In sit amet ligula dapibus, gravida est at, \nconsequat tellus. Pellentesque a imperdiet ligula, eu facilisis ante. \nSuspendisse cursus fermentum ipsum, id tempus sapien luctus a. Nam sed \ntellus et lacus sagittis ultrices vel nec purus. Duis non vestibulum \nligula. Aenean vitae tristique sapien, non fringilla purus.', '2016-01-25 16:38:48', 'professor-paulinho-investe-em-artesanato', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL,
  `moderador_id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ultimo_login` datetime NOT NULL,
  `nivel` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `moderador_id`, `email`, `senha`, `ultimo_login`, `nivel`) VALUES
(1, 1, 'admin@site.com', 'e10adc3949ba59abbe56e057f20f883e', '2015-11-19 00:00:00', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `denuncia`
--
ALTER TABLE `denuncia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moderador`
--
ALTER TABLE `moderador`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticia_principal`
--
ALTER TABLE `noticia_principal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticia_quaternaria`
--
ALTER TABLE `noticia_quaternaria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticia_quinaria`
--
ALTER TABLE `noticia_quinaria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticia_secundaria`
--
ALTER TABLE `noticia_secundaria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticia_senaria`
--
ALTER TABLE `noticia_senaria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticia_terciaria`
--
ALTER TABLE `noticia_terciaria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `denuncia`
--
ALTER TABLE `denuncia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `moderador`
--
ALTER TABLE `moderador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `noticia_principal`
--
ALTER TABLE `noticia_principal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `noticia_quaternaria`
--
ALTER TABLE `noticia_quaternaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `noticia_quinaria`
--
ALTER TABLE `noticia_quinaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `noticia_secundaria`
--
ALTER TABLE `noticia_secundaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `noticia_senaria`
--
ALTER TABLE `noticia_senaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `noticia_terciaria`
--
ALTER TABLE `noticia_terciaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
